<?php 
// Update the path below to your autoload.php, 
// see https://getcomposer.org/doc/01-basic-usage.md 
require_once 'vendor/autoload.php'; 
 
use Twilio\Rest\Client; 
 
$sid    = ""; 
$token  = ""; 
$twilio = new Client($sid, $token); 


$sender = $_POST['From'];
$msg    = $_POST['Body'];

$twilio_number = "+14155238886";

$cmd = trim(strtoupper(substr($msg,0,5)));

// =================================================================
switch ($cmd) {
    case 'ESS':
        $body = "Hello ". $sender  .
                "\n\nTerima Kasih sudah menghubungi ESS SERVICE, Silakan reply menu ESS berikut :\n" .
                "\nCUTI <tgl1> <tgl2> <keterangan>" .
                "\nLEMBUR  <tgl1> <keterangan>" .
                "\nBROSUR <MMYYYY>" .
                "\n" .
                "\nContoh: \nCUTI 15/01/2020 15/01/2020 Keperluan Pribadi\n" . 
                "BROSUR 012020";
        $mediaUrl  = "http://www.jrryptr.com/twiliophp/files/welcome.png";
        break;
    case 'CUTI':
        $body = "Hello ". $sender .
                "\n\nCuti Anda sudah di proses \nTerima Kasih\n\nESS BOT SERVICE";
        $mediaUrl  = "http://www.jrryptr.com/twiliophp/files/thanks.png";                
        break;      
    case 'LEMBU':
        $body = "Hello ". $sender .
                "\n\nCuti Anda sudah di proses \nTerima Kasih\n\nESS BOT SERVICE";
        $mediaUrl  = "http://www.jrryptr.com/twiliophp/files/thanks.png";               
        break;             
    case 'BROSU':
        $body = "Hello ". $username .
                "\n\nBerikut Brosur untuk periode yang diminta \n\nTerima Kasih\n\nESS BOT SERVICE";
        $mediaUrl  = "http://www.jrryptr.com/twiliophp/files/thanks.png";                
        break;        
    default:
        $body = "Terima kasih sudah menghubungi ESS BOT SERVICE, \n\nSaat ini permintaan anda belum tersedia, silakan hubungi Team Support Kami melalui Telephone " .
                "\n\n atau \n\n" . 
                "Reply dengan pesan 'ESS' tanpa tanda petik untuk melihat menu ESS yang tersedia \n\nESS BOT SERVICE \n\n". 
                "-------------------------------------\n" .
                "{Sender: " . $sender . "}\n" .
                "{Message: " . $msg . "}";
        $mediaUrl  = "http://www.jrryptr.com/twiliophp/files/error.png";                
        break;
}


$message = $twilio->messages 
                  ->create($sender , // to 
                           array( 
                               "from" => "whatsapp:$twilio_number",       
                               "body" => $body,
                               "mediaUrl" => [$mediaUrl]
                           ) 
                  ); 
 


//-- Brosur ---
if ($cmd == 'BROSU') {
    $mediaUrl  = "http://www.jrryptr.com/twiliophp/files/brosur.pdf";  

    $message = $twilio->messages 
    ->create($sender , // to 
             array( 
                 "from" => "whatsapp:$twilio_number",       
                 "body" => $body,
                 "mediaUrl" => [$mediaUrl]
             ) 
    ); 
}

