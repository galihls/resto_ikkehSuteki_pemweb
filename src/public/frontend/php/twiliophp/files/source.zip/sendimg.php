<?php 
 
// Update the path below to your autoload.php, 
// see https://getcomposer.org/doc/01-basic-usage.md 
require_once 'vendor/autoload.php'; 
 
use Twilio\Rest\Client; 
 
$sid    = ""; 
$token  = ""; 
$twilio = new Client($sid, $token); 

$to = "whatsapp:+62";
$from = "whatsapp:+14155238886";
$body = "Pesan Whatsapp dengan Gambar";
$mediaUrl = "http://www.jrryptr.com/twilio/files/office.jpg";

 
$message = $twilio->messages 
                  ->create($to, // to 
                           array( 
                               "from" => $from,       
                               "body" => $body,
                               "mediaUrl" => [$mediaUrl]
                           ) 
                  ); 
 
print($message->sid);